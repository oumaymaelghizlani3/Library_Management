{'name': "library ",
 'version': '1.0',
 'depends': ['base'],
 'author': "New odoo",
 'category':  'Uncategorized',
 'description': """ Description text """,

'data': [
    'security/ir.model.access.csv',
    'views/viewsbook.xml',
    'views/viewsauthor.xml',
    'views/viewscustomer.xml','views/viewslocation.xml'
    ],
}
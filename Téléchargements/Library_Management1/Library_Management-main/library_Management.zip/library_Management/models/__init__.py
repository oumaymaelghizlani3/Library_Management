# -*- encoding: utf-8 -*-
from . import customer
from . import author
from . import book
from . import location
